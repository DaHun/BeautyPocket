package com.sopt.BeautyPocket.model;

import android.content.Intent;

import java.util.ArrayList;

/**
 * Created by user on 2017-01-03.
 */

public class CalendarCheck {
    String a;
    ArrayList<String> day;


    public CalendarCheck(ArrayList<String> day){
        this.day = day;
    }
}
