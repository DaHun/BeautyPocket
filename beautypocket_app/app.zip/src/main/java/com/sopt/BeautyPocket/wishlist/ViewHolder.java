package com.sopt.BeautyPocket.wishlist;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by dhlee on 2016-12-30.
 */

public class ViewHolder {
    CheckBox cb_grid;
    ImageView img_grid;
    TextView tv_grid_productname;
    TextView tv_grid_price;
    ImageView btn_gobrandmap;
}
