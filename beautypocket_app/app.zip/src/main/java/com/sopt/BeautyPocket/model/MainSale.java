package com.sopt.BeautyPocket.model;

import java.io.Serializable;

/**
 * Created by user on 2017-01-03.
 */

public class MainSale implements Serializable{
    public int mainsale_id;
    public int brand_id;
    public String sale_info;
    public String sale_day;
    public String sale_image;
    public String sale_title;
}