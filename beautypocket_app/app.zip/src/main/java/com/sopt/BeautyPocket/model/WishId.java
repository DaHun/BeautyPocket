package com.sopt.BeautyPocket.model;

/**
 * Created by USER on 2017-01-02.
 */
public class WishId {
    int wish_id;

    public WishId(int wish_id) {
        this.wish_id = wish_id;
    }

    public int getWish_id() {
        return wish_id;
    }

    public void setWish_id(int wish_id) {
        this.wish_id = wish_id;
    }
}