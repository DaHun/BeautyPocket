package com.sopt.BeautyPocket.calender;

/**
 * Created by user on 2016-12-31.
 */

public class saleData {
    String d1;
    String d2;

    public saleData(String d1, String d2) {
        this.d1 = d1;
        this.d2 = d2;
    }

    public String getD1() {
        return d1;
    }

    public void setD1(String d1) {
        this.d1 = d1;
    }

    public String getD2() {
        return d2;
    }

    public void setD2(String d2) {
        this.d2 = d2;
    }
}
