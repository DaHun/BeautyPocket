package com.sopt.BeautyPocket.model;

/**
 * Created by user on 2017-01-03.
 */

public class TwoDate {
    String d1;
    String d2;

    public TwoDate(String d1, String d2) {
        this.d1 = d1;
        this.d2 = d2;
    }

    public String getD1() {
        return d1;
    }

    public void setD1(String d1) {
        this.d1 = d1;
    }

    public String getD2() {
        return d2;
    }

    public void setD2(String d2) {
        this.d2 = d2;
    }
}
