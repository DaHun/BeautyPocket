package com.sopt.BeautyPocket.wishlist_brand;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by samsung on 2017-01-04.
 */
public class BrandViewHolder {
    ImageView image_brand;
    TextView tv_brand;
}